//
// Created by xiaotian on 2021/12/13.
//

#ifndef TEMPLATEF401CEU6_DELAY_H
#define TEMPLATEF401CEU6_DELAY_H

void Delay_us(uint32_t xus);
void Delay_ms(uint32_t xms);
void Delay_s(uint32_t xs);

#endif //TEMPLATEF401CEU6_DELAY_H
